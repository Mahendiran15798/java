package com.example.retrofit_new.Network;

import com.example.retrofit_new.Model.ProductItem;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface APIInterface {
    @GET("posts")
    Call<ArrayList<ProductItem>>getproduct();
}
