package com.example.retrofit_new.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.retrofit_new.Model.ProductItem;
import com.example.retrofit_new.R;

import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<ProductItem> mItemList;

    public ProductAdapter(Context context, ArrayList<ProductItem> mItemList){

        this.context=context;
        this.mItemList=mItemList;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemview= LayoutInflater.from(parent.getContext()).inflate(R.layout.inflate_product,parent,false);
        return new MyViewHolder(itemview);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        ProductItem item =mItemList.get(position);

        String id = item.getId().toString();

        Log.d("id", id);


        holder.txtId.setText(id);
        holder.txtUserId.setText(item.getUserId().toString());
        holder.txtTitle.setText(item.getTitle());
        holder.txtbody.setText(item.getBody());

    }

    @Override
    public int getItemCount() {
        return mItemList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView txtId,txtUserId,txtTitle,txtbody;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtId=(TextView)itemView.findViewById(R.id.txtId);
            txtUserId=(TextView)itemView.findViewById(R.id.txtUserId);
            txtTitle=(TextView)itemView.findViewById(R.id.txtTitle);
            txtbody=(TextView)itemView.findViewById(R.id.txtbody);
        }
    }
}
