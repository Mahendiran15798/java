package com.example.menu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {


    LinearLayout linearLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout=findViewById(R.id.lin);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater=getMenuInflater();
        menuInflater.inflate(R.menu.option_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.a:
                linearLayout.setBackgroundColor(Color.parseColor("#c1c1c1"));
                return true;
            case R.id.b:
                linearLayout.setBackgroundColor(Color.parseColor("#ff0000"));
                return true;
            case R.id.c:
                linearLayout.setBackgroundColor(Color.parseColor("#008000"));
                return true;
            case R.id.d:
                linearLayout.setBackgroundColor(Color.parseColor("#ff7f00"));
                return true;
            case R.id.privacy:
                linearLayout.setBackgroundColor(Color.parseColor("#ff0f00"));
                return true;
            case R.id.help:
                linearLayout.setBackgroundColor(Color.parseColor("#000fff"));
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}