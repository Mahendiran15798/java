package com.example.fragment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private String[] DATA = new String[]{"Quiz 1", "Quiz 2", "Quiz 3", "Quiz 4", "Quiz 5", "Quiz 6", "Quiz 7"};
    int QUIZ_COUNT = DATA.length;
    int CurrentPage = -1;

    TextView pageNumber;
    Button preBtn, nxtBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pageNumber = (TextView) findViewById(R.id.pageNumber);
        preBtn = (Button) findViewById(R.id.preBtn);
        nxtBtn = (Button) findViewById(R.id.nxtBtn);

        preBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                preQuiz();

            }
        });
        nxtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nxtQuiz();

            }
        });
        nxtQuiz();
    }


    public void nxtQuiz() {
        CurrentPage += 1;
        if (CurrentPage > QUIZ_COUNT - 1) {
            CurrentPage = QUIZ_COUNT - 1;
        }

        String title = DATA[CurrentPage];

        CreatePage(title);
        updatePageCount();
    }

    public void preQuiz() {
        CurrentPage -= 1;
        if (CurrentPage < 0) {
            CurrentPage = 0;
        }

        String title = DATA[CurrentPage];

        CreatePage(title);
        updatePageCount();

    }

    public void CreatePage(String title) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transanction = fragmentManager.beginTransaction();

        Quiz_Fragment quizFragment = Quiz_Fragment.getInstance(title);

        transanction.replace(R.id.quizContainer, quizFragment, title);
        transanction.commit();

    }

    private void updatePageCount() {
        String pageCount = " " + (CurrentPage + 1) + "/" + QUIZ_COUNT;
        pageNumber.setText(pageCount);
    }
}