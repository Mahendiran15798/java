package com.example.contextmenu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    TextView contextMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contextMenu=findViewById(R.id.textview);
        imageView=findViewById(R.id.imageview);
        registerForContextMenu(contextMenu);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("select a image");
        getMenuInflater().inflate(R.menu.contextmenu,menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.apple:
                imageView.setImageResource(R.drawable.apple);
                Toast.makeText(this,"Apple",Toast.LENGTH_LONG).show();
                return true;
            case R.id.boll:
                imageView.setImageResource(R.drawable.ball);
                Toast.makeText(this,"Boll",Toast.LENGTH_LONG).show();
                return true;
            case R.id.cat:
                imageView.setImageResource(R.drawable.cat);
                Toast.makeText(this,"Cat",Toast.LENGTH_LONG).show();
                return true;
            case R.id.dog:
                imageView.setImageResource(R.drawable.dog);
                Toast.makeText(this,"Dog",Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}