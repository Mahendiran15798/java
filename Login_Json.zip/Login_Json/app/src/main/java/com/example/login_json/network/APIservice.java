package com.example.login_json.network;

import com.example.login_json.model.ShowModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface APIservice {
    @GET("Volley_array.json")
    Call<List<ShowModel>> getShowModel();
}
