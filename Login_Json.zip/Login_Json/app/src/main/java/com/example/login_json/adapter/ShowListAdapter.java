package com.example.login_json.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login_json.MainActivity;
import com.example.login_json.R;
import com.example.login_json.model.ShowModel;

import java.util.List;

public class ShowListAdapter extends RecyclerView.Adapter<ShowListAdapter.MyViewHolder> {
    private Context context;
    private List<ShowModel> showModels;

    public ShowListAdapter(MainActivity mainActivity, List<ShowModel> showModelList) {

        this.context = context;
        this.showModels = showModels;

    }

    public void setShowModels(List<ShowModel> showModels) {
        this.showModels = showModels;
        notifyDataSetChanged();

    }

    @NonNull
    @Override
    public ShowListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ShowListAdapter.MyViewHolder holder, int position) {

        String timePoint = String.valueOf(showModels.get(position).getTimepoint());
        holder.textView1.setText(timePoint);
        String cloudCover = String.valueOf(showModels.get(position).getCloudcover());
        holder.textView1.setText(cloudCover);
        String lifted_index = String.valueOf(showModels.get(position).getLifted_index());
        holder.textView1.setText(lifted_index);
        String seeing = String.valueOf(showModels.get(position).getSeeing());
        holder.textView1.setText(seeing);
        String transparency = String.valueOf(showModels.get(position).getTransparency());
        holder.textView1.setText(transparency);
        String rh = String.valueOf(showModels.get(position).getRh2m());
        holder.textView1.setText(rh);

    }

    @Override
    public int getItemCount() {
        if (this.showModels !=null){
            return this.showModels.size();
        }
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView textView1, textView2, textView3, textView4, textView5, textView6;

        public MyViewHolder(View itemview) {
            super(itemview);
            textView1 = (TextView) itemview.findViewById(R.id.textview1);
            textView2 = (TextView) itemview.findViewById(R.id.textview2);
            textView3 = (TextView) itemview.findViewById(R.id.textview3);
            textView4 = (TextView) itemview.findViewById(R.id.textview4);
            textView5 = (TextView) itemview.findViewById(R.id.textview5);
        }
    }
}
