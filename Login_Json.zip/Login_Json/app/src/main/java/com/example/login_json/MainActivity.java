package com.example.login_json;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.example.login_json.adapter.ShowListAdapter;
import com.example.login_json.model.ShowModel;
import com.example.login_json.viewmodel.ListViewModel;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<ShowModel> showModelList;
    private ShowListAdapter adapter;
    private ListViewModel viewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerview = findViewById(R.id.recyclerview);
        final TextView result = findViewById(R.id.Result);
        LinearLayoutManager layoutManager = new GridLayoutManager(this, 2);
        recyclerview.setLayoutManager(layoutManager);
        adapter = new ShowListAdapter(this, showModelList);
        recyclerview.setAdapter(adapter);

        viewModel = ViewModelProviders.of(this).get(ListViewModel.class);
        viewModel.getShowDataObserver().observe(this, new Observer<List<ShowModel>>() {
            @Override
            public void onChanged(List<ShowModel> showModels) {
                if (showModels != null) {
                    showModelList = showModels;
                    adapter.setShowModels(showModels);
                    result.setVisibility(View.GONE);
                }else{
                    result.setVisibility(View.VISIBLE);

                }
            }
        });
    }
}