package com.example.login_json.model;

public class ShowModel {



    private int timepoint,cloudcover,seeing,transparency,lifted_index,rh2m;

    public ShowModel(int timepoint, int cloudcover, int seeing, int transparency, int lifted_index, int rh2m) {

        this.cloudcover=cloudcover;
        this.timepoint=timepoint;
        this.seeing=seeing;
        this.transparency=transparency;
        this.lifted_index=lifted_index;
        this.rh2m=rh2m;

    }
    public int getTimepoint() {
        return timepoint;
    }

    public void setTimepoint(int timepoint) {
        this.timepoint = timepoint;
    }

    public int getCloudcover() {
        return cloudcover;
    }

    public void setCloudcover(int cloudcover) {
        this.cloudcover = cloudcover;
    }

    public int getSeeing() {
        return seeing;
    }

    public void setSeeing(int seeing) {
        this.seeing = seeing;
    }

    public int getTransparency() {
        return transparency;
    }

    public void setTransparency(int transparency) {
        this.transparency = transparency;
    }

    public int getLifted_index() {
        return lifted_index;
    }

    public void setLifted_index(int lifted_index) {
        this.lifted_index = lifted_index;
    }

    public int getRh2m() {
        return rh2m;
    }

    public void setRh2m(int rh2m) {
        this.rh2m = rh2m;
    }
}
