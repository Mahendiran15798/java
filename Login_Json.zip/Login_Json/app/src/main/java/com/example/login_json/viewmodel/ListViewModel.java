package com.example.login_json.viewmodel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.login_json.model.ShowModel;
import com.example.login_json.network.APIservice;
import com.example.login_json.network.RetroInstance;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ListViewModel extends ViewModel {

    private MutableLiveData<List<ShowModel>> showData;
    public ListViewModel(){
        showData =new MutableLiveData<>();


    }
    public MutableLiveData<List<ShowModel>> getShowDataObserver(){
        return showData;
    }

    public void makeApiCall(){
        APIservice apIservice= RetroInstance.getRetroClient().create(APIservice.class);
        Call<List<ShowModel>> call =apIservice.getShowModel();
        call.enqueue(new Callback<List<ShowModel>>() {
            @Override
            public void onResponse(Call<List<ShowModel>> call, Response<List<ShowModel>> response) {

                showData.postValue(response.body());

            }

            @Override
            public void onFailure(Call<List<ShowModel>> call, Throwable t) {

                showData.postValue(null);
            }
        });
    }
}
