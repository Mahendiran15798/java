package com.example.httpurl_connection;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private TextView textview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button =(Button)findViewById(R.id.button);
        textview =(TextView) findViewById(R.id.textview);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new JsonTask().execute("https://socialnetwork022021-default-rtdb.firebaseio.com/Users.json");
            }
        });


    }
    public class JsonTask extends AsyncTask<String, String, StringBuffer> {

        @Override
        protected StringBuffer doInBackground(String... params) {


            HttpURLConnection connection = null;
            BufferedReader reader =null;
            try {
                //     URL url = new URL("https://reqres.in/api/users?page=2");
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();

                InputStream inputStream =connection.getInputStream();
                reader =new BufferedReader(new InputStreamReader(inputStream));

                StringBuffer buffer =new StringBuffer();
                String line ="";
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }
                return buffer.append(line);
            }
            catch (MalformedURLException e) {
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                if (connection != null) {
                    connection.disconnect();
                }

                try {
                    if (reader != null) {
                        reader.close();
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(StringBuffer result) {
            super.onPostExecute(result);
            textview.setText(result);

        }
    }

}